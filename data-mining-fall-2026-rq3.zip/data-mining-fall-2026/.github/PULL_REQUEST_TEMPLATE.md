## What changed?
[Explain code and outputs added or updated.]

## Which research question or shared component?
[RQ1 / RQ2 / RQ3 / Shared]

## How was it tested?
[Commands and checks performed.]

## Does this change require AI-use disclosure?
[Describe relevant AI-generated/restructured experiment code or debugging, or say none.]

## Reviewer checklist
- [ ] Code runs on the shared setup
- [ ] No raw dataset or credentials committed
- [ ] No test-set leakage / information leakage introduced
- [ ] Claims and saved figures match actual code outputs
